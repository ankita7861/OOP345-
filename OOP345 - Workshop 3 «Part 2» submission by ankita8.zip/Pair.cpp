/***********************************************************************
// OOP345 Workshop #3 lab
//
// File  Pair.cpp
// Name- -Ankita
// Email- ankita8@myseneca.ca
// Student ID- 169726213
// Date- 01-02-2024

// Citation:

//  I have done all the coding by myself and only copied the code that my professor provided to complete my workshops and assignments.
***********************************************************************/



#include "Pair.h"

using namespace std;


namespace seneca
{

    bool Pair::haveSameKey(const Pair& L, const Pair& M) {
        bool res = false;
        if (L.m_key == M.m_key) {
            res = true;
        }
        return res;
    }

    std::ostream& Pair::display(std::ostream& ostr) const {
        ostr.width(20);
        ostr.setf(ios::right);
        ostr << getKey();
        ostr.setf(ios::left);
        ostr << ": " << getValue();
        return ostr;
    }

    std::ostream& operator<<(std::ostream& ostr, const Pair& L) {
        return L.display(ostr);
    }
}