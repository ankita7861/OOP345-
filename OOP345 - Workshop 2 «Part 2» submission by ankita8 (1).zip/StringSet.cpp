/*
Name: Ankita
Student I'd: 169726213
Date: 26-01-2024
 I have done all the coding by myself and only copied the code that my professor provided to complete my workshops and assignments.*/
#include <fstream>
#include "StringSet.h"
#include "utility"
using namespace seneca;

StringSet::StringSet() {}

StringSet::StringSet(const char* cstr)
{
	std::ifstream fin(cstr);
	std::string word;
	size_t count = 0;
	while (std::getline(fin, word, ' '))count++;
	a_numOfstring = count;
	a_stringArray = new std::string[a_numOfstring];
	fin.clear();
	fin.seekg(0);
	size_t i = 0;
	while (std::getline(fin, a_stringArray[i++], ' '));
}

StringSet::StringSet(const StringSet& I)
{
	*this = I;
}

seneca::StringSet::StringSet(StringSet&& I)
{
	*this = std::move(I);
}

StringSet::~StringSet()
{
	delete[] a_stringArray;
}

StringSet& StringSet::operator=(const StringSet& other)
{
	if (this != &other)
	{
		delete[] a_stringArray;
		a_numOfstring = other.a_numOfstring;
		a_stringArray = new std::string[a_numOfstring];
		for (size_t i = 0; i < a_numOfstring; i++)
		{
			a_stringArray[i] = other.a_stringArray[i];
		}
	}
	return *this;
}

StringSet& StringSet::operator=(StringSet&& other)
{
	if (this != &other)
	{
		delete[] a_stringArray;
		a_numOfstring = other.a_numOfstring;
		a_stringArray = other.a_stringArray;
		other.a_stringArray = nullptr;
		other.a_numOfstring = 0;
	}
	return *this;
}

size_t StringSet::size() const
{
	return a_numOfstring;
}

std::string StringSet::operator[](size_t index) const
{
	return (index >= 0 && index < a_numOfstring) ? a_stringArray[index] : "";
}
