/*
Name: Ankita
Student I'd: 169726213
Date: 26-01-2024
 I have done all the coding by myself and only copied the code that my professor provided to complete my workshops and assignments.*/
#ifndef SENECA_TIMEDEVENTS_H
#define SENECA_TIMEDEVENTS_H
#include <chrono>
#include <string>


const unsigned int maxNumofEvents = 10;

namespace seneca{
	class TimedEvents {
		unsigned int a_numOfRecords;
		std::chrono::steady_clock::time_point a_startTime;
		std::chrono::steady_clock::time_point a_endTime;
		struct Event {
			std::string eventName;
			std::string predefUnitTime;
			std::chrono::steady_clock::duration duration;
		}a_events[maxNumofEvents];


	public:
		TimedEvents();
		TimedEvents& startClock();
		TimedEvents& stopClock();
		TimedEvents& addEvent(const char* cstr);
		friend std::ostream& operator<<(std::ostream& os, const TimedEvents& te);
	};
}
#endif 

