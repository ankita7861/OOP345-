/*
Name: Ankita
Student I'd: 169726213
Date: 26-01-2024
 I have done all the coding by myself and only copied the code that my professor provided to complete my workshops and assignments.*/
#include <iostream>
#include <iomanip>
#include <cstring>
#include "TimedEvents.h"


namespace seneca {
	TimedEvents::TimedEvents() : a_numOfRecords(0) {}
	TimedEvents& TimedEvents::startClock()
	{
		a_startTime = std::chrono::steady_clock::now();
		return *this;
	}
	TimedEvents& TimedEvents::stopClock()
	{
		a_endTime = std::chrono::steady_clock::now();
		return *this;

	}
	TimedEvents& TimedEvents::addEvent(const char* cstr)
	{
		a_events[a_numOfRecords].eventName = cstr;
		a_events[a_numOfRecords].predefUnitTime = "nanoseconds";
		a_events[a_numOfRecords].duration = std::chrono::duration_cast<std::chrono::nanoseconds>(a_endTime - a_startTime);
		a_numOfRecords++;
		return *this;
	}
	std::ostream& operator<<(std::ostream& os, const TimedEvents& te)
	{
		std::cout << "--------------------------" << std::endl;
		std::cout << "Execution Times:" << std::endl;
		std::cout << "--------------------------" << std::endl;
		for (int i = 0; i < (int)te.a_numOfRecords; i++) {
			std::cout << std::setw(21) << std::left << te.a_events[i].eventName;
			std::cout << std::setw(13) << std::right << te.a_events[i].duration.count() << ' ';
			std::cout << te.a_events[i].predefUnitTime << std::endl;
		}
		std::cout << "--------------------------" << std::endl;
		return os;
	}
}