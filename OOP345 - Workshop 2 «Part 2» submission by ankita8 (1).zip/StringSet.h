/*
Name: Ankita
Student I'd: 169726213
Date: 26-01-2024
 I have done all the coding by myself and only copied the code that my professor provided to complete my workshops and assignments.*/
#ifndef SENECA_STRINGSET_H
#define SENECA_STRINGSET_H
#include <string>

namespace seneca {
	class StringSet {
		std::string* a_stringArray = nullptr;
		size_t a_numOfstring = 0;
	public:
		StringSet();
		StringSet(const char* cstr);
		StringSet(const StringSet& I);
		StringSet(StringSet&& I);
		~StringSet();
		StringSet& operator=(const StringSet& other);
		StringSet& operator=(StringSet&& other);
		size_t size() const;
		std::string operator[](size_t index) const;
	};
}



#endif // !SENECA_STRINGSET_H