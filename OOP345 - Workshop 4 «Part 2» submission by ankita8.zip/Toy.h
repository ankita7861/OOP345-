
/***********************************************************************
// OOP345 Workshop #4 lab
//
// File  Toy.h
// Name- -Ankita
// Email- ankita8@myseneca.ca
// Student ID- 169726213
// Date- 10-02-2024

// Citation:

//  I have done all the coding by myself and only copied the code that my professor provided to complete my workshops and assignments.
***********************************************************************/




#ifndef SENECA_TOY_H
#define SENECA_TOY_H

#include <iostream>
#include <iomanip>
#include <fstream>
#include <string>
#include <sstream>
#include <cstring>
#include <utility>

namespace seneca
{
	class Toy
	{
		unsigned int OrderId{ 0 };
		std::string Toy_Name{};
		double Toy_Price{ 0 };
		int itemHST{ 13 };
	public:

		size_t count{ 0 };


		Toy();
		Toy(const std::string& toy);
		void update(int numItems);
		Toy(const Toy& obj);
		Toy& operator=(const Toy& obj);


		~Toy();
		friend std::ostream& operator <<(std::ostream& os, const Toy& obj);
	};
}
#endif // TOY_H
